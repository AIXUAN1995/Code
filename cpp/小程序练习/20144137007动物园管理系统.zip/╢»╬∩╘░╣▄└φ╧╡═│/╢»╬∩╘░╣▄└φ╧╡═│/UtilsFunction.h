#include<iostream>
using namespace std;
#include<string>
#include<fstream>
#include"head.h"
string str[5] = { "dog", "tiger","panda","lion", "wolf",};
class UtilsFunction{
public:
	int isEmpty(int num){
		if (num == 0)
			cout << "\t\t\t���޸��ද�" << endl;
		//cout << num << "------------" << endl;
		return num;
	}
	void proUtil(char * pro){
		cout << "����԰�ж��������У�" << endl;
		for (int i = 0; i < 5; i++)
			cout << str[i] << "\t";
		cout << "\n�����붯������ࣺ";
		cin >> pro;
		int i = 0;
		do{
			for (i = 0; i < 5; i++)
			if (pro == str[i])
				break;
			if (i >= 5){
				system("cls");
				cout << "û�и��ද�����������!" << endl;
				for (int i = 0; i < 5; i++)
					cout << str[i] << "\t";
				cout << "\n�����붯������ࣺ";
				cin >> pro;
			}
		} while (i >= 5);

	}
//----------------------------------------------------��ӡ��ϢUtil------------------------------------------
	void megUtil(AM M){
		cout << "\t\t\t��������ࣺ" << M.pro << endl;
		cout << "\t\t\t����ı�ţ�" << M.num << endl;
		cout << "\t\t\t�������֣�" << M.name << endl;
		cout << "\t\t\t������Ա�" << M.sex << endl;
		cout << "\t\t\t��������䣺" << M.age << endl;
		cout << "\t\t\t�������Ϣ����Ϊ��" << M.msg << endl;
	}
	void megSelectOneUtil(AM M){
		cout << "\t\t\t��������ࣺ" << M.pro << endl;
		cout << "\t\t\t����ı�ţ�" << M.num << endl;
	}
	void megUtil(LG M){
		cout << "\t\t\t�ο͵��û�����" << M.username << endl;
		cout << "\t\t\t�ο͵����룺" << M.password<< endl;
		
	}
	int megSelectOneClassUtil(AM &M,AS sum,string name,int Sum){
			if (!isEmpty(Sum))
				return -1;
			cout << "\t" << name << "����ϢΪ��" << endl;
			for (int i = 0; i < Sum; i++)
			if (ifileUtil(M, i, name) != -1){
				cout << "\t\t\t" << i + 1 << "." << endl;
				megSelectOneUtil(M);
				cout << "\t\t------------------------------------" << endl;
			}
			return 0;
	}
	void megOneClassUtil(AM &M,string name, int Sum){
		if (!isEmpty(Sum))
			return;
		cout << "\t"<<name<<"����ϢΪ��" << endl;
		for (int i = 0; i < Sum; i++)
		if (ifileUtil(M, i, name) != -1){
			cout <<"\t\t\t" <<i + 1 << "." << endl;
			megUtil(M);
			cout << "\t\t------------------------------------" << endl;
		}
		
}
	void megOneUtil(AM &M, AS sum, string name, int Sum, char * num){
		cout << "\t" << name << "����ϢΪ��" << endl;
		int i;
		ifileUtil(sum, "sum");
		for (i = 0; i <Sum; i++)
		if (ifileUtil(M, i, name) != -1){
			if (!strcmp(M.num, num)){

				M.count = i;
				megUtil(M);
				break;
			}


		}
		//cout << i << "----------------" <<Sum<< endl;
		//cout << i << "\t" << Sum << endl;
		if (i >=Sum){
			cout << "�޴˱�Ŷ���!!!" << endl;
			M.count = -1;
		}
			

	}
	
	void megUser(LG &M, AS sum, string name, int Sum){
	
		for (int i = 0; i <Sum; i++)
		if (ifileUtil(M, i, name) != -1){
		
			cout <<"\t\t�οͱ�ţ�" <<i + 1 << endl;
			megUtil(M);
			cout << "\t\t------------------------------------" << endl;
			//cout << M.username << endl;
		}
	}
	void megOneUser(LG &M,string name, int &i){
		//cout << "megUser-------------------" << endl;
		//ifileUtil(sum, "sum");
		//cout << sum.user<<"sum.user-------------------------------"<<endl;
		if (ifileUtil(M, i-1, name) != -1){
			cout << "\t\t\t" << i << "." << endl;
			
			megUtil(M);
			
			cout << "\t\t------------------------------------" << endl;
		}

	}
//------------------------------------------ɾ��Util-----------------------------------------------------
	void DelUser(LG &M, string name, int j,int Sum){
		string is;
		cout << "������ɣ��Ƿ�Ҫɾ��(Y|N)��";
		cin >> is;
		if (is == "Y" || is == "y"){
			for (int i = 1; i <= Sum; i++){
				if (i == j)
					continue;
				ifileUtil(M, i - 1, name);
				ofileUtil(M, "temp");

			}
			ofstream delU("./systemFile/"+name  + ".dat", ios::trunc);
			for (int i = 1; i <= Sum - 1; i++){
				ifileUtil(M, i - 1, "temp");
				ofileUtil(M, name);
			}
			ofstream delT("./systemFile/temp.dat", ios::trunc);
			AS sum;
			ifileUtil(sum, "sum");
			sum.user--;
			ofileUtil(sum, "sum");
			system("cls");
			cout << "ɾ���ɹ���" << endl;
		}
		else if (is == "N" || is == "n"){
			system("cls");
			cout << "û��ɾ�����Զ�������һ��..." << endl;
			return;
		}
		else{
			system("cls");
			cout << "��������Զ�������һ��..." << endl;
			return;
		}
			
		
	}
	int DelAnimal(AM &M, string name, char* num, int Sum){
		int test = 1;
		for (int i = 1; i <= Sum; i++){
			ifileUtil(M, i - 1, name);
			if (!strcmp(M.num, num)){
				test = 0;
				continue;
			}	
			ofileUtil(M, "temp");

		}
		if (test == 1){
			cout << "ɾ��ʧ�ܣ��޴˱�Ŷ��" << endl;
			return 1;
		}
			
			
		ofstream delU("./systemFile/"+name  + ".dat", ios::trunc);
		for (int i = 1; i <= Sum - 1; i++){
			ifileUtil(M, i - 1, "temp");
			ofileUtil(M, name);
		}
		ofstream delT("./systemFile/temp.dat", ios::trunc);
		return 0;
	}
	void DelAnimalUtil(AM &M,string name, char*num){
		cout << "������Ҫɾ���Ķ���ı�ţ�";
		cin >> num;
		string is;
		AS sum;
		ifileUtil(sum, "sum");
		cout << "������ɣ��Ƿ�Ҫɾ��(Y|N)��";
		cin >> is;
		if (is == "Y" || is == "y"){
			if (name == "dog"){
				if (DelAnimal(M, name, num, sum.dog))
					return;
				sum.dog--;
			}
			else if (name == "tiger"){
				if (DelAnimal(M, name, num, sum.tiger))return;
				sum.tiger--;
			}
			else if (name == "panda"){
				if (DelAnimal(M, name, num, sum.panda))return;
				sum.panda--;
			}
			else if (name == "lion"){
				if (DelAnimal(M, name, num, sum.lion))return;
				sum.lion--;
			}
			else if (name == "wolf"){
				if (DelAnimal(M, name, num, sum.wolf))return;
				sum.wolf--;
			}
			ofileUtil(sum, "sum");
			system("cls");
			cout << "ɾ���ɹ���" << endl;
		}
		else if (is == "N" || is == "n"){
			system("cls");
			cout << "û��ɾ�����Զ�������һ��..." << endl;
			return;
		}
		else{
			system("cls");
			cout << "��������Զ�������һ��..." << endl;
			return;
		}

		
		
	}
	
//----------------------------------------------��д�ļ�Util-----------------------------------------------------



	int ofileUtil(AM &M, string name){
		ofstream ofile("./systemFile/"+name  + ".dat",ios::app);
		if (!ofile){
			cout << "���ļ�ʧ��" << endl;
			return -1;
		}
		//ofile.seekp(2*sizeof(M),ios::beg);
		ofile.write((char *)&M, sizeof(M));
		ofile.close();
		return 0;
	}
	int ofileUtil(AM &M, string name,int i){
		ofstream ofile("./systemFile/"+name  + ".dat", ios_base::in|ios::out);
		if (!ofile){
			cout << "���ļ�ʧ��" << endl;
			return -1;
		}
		//cout << "*****" << endl;
		ofile.seekp(i*sizeof(M),ios_base::beg);
		ofile.write((char *)&M, sizeof(M));
		ofile.close();
		return 0;
	}
	int ifileUtil(AM &M, string name){
		ifstream ifile("./systemFile/"+name  + ".dat", ios_base::in);
		if (!ifile){
			cout << "���ļ�ʧ��" << endl;
			return -1;
		}
		//ifile.read((char *)&M, sizeof(M));
		ifile.close();
		return 0;
	}
	int ifileUtil(AM &M,int i, string name){
		ifstream ifile("./systemFile/"+name  + ".dat", ios_base::in);
		if (!ifile){
			cout << "���ļ�ʧ�ܣ�" << endl;
			return -1;
		}
		ifile.seekg(i*sizeof(M));
		ifile.read((char *)&M, sizeof(M));
		ifile.close();
		return 0;
	}
	int ifileUtil(LG &M, int i, string name){
		ifstream ifile("./systemFile/"+name  + ".dat", ios_base::in);
		if (!ifile){
			cout << "���ļ�ʧ��" << endl;
			return -1;
		}
		//cout << M.username << "----" << M.password << "-----" << endl;
		//cout << "i=" << i << endl;
		ifile.seekg(i*sizeof(M));
		//cout << M.username << "----" << M.password << "-----" << endl;
		ifile.read((char *)&M, sizeof(M));
		//cout << M.username <<"---"<< endl;
		//cout << M.username << "----" << M.password << "-----" << endl;
		ifile.close();
		return 0;
	}
	int ofileUtil(LG &M, int i, string name){
		ofstream ofile("./systemFile/"+name  + ".dat", ios::in|ios::out);
		if (!ofile){
			cout << "���ļ�ʧ��" << endl;
			return -1;
		}
		//cout << M.username << "----" << M.password << "-----" << endl;
		//cout << "i=" << i << endl;
		ofile.seekp((i-1)*sizeof(M));
		//cout << M.username << "----" << M.password << "-----" << endl;
		ofile.write((char *)&M, sizeof(M));
		//cout << M.username <<"---"<< endl;
		//cout << M.username << "----" << M.password << "-----" << endl;
		ofile.close();
		return 0;
	}

	int ofileUtil(AS &M, string name){
		ofstream ofile("./systemFile/"+name  + ".dat", ios_base::trunc);
		if (!ofile){
			cout << "���ļ�ʧ��" << endl;
			return -1;
		}
		ofile.write((char *)&M, sizeof(M));
		ofile.close();
		return 0;
	}
	int ifileUtil(AS &M, string name){
		ifstream ifile("./systemFile/"+name  + ".dat", ios_base::in);
		if (!ifile){
			return -1;
		}
		ifile.read((char *)&M, sizeof(M));
		ifile.close();
		return 0;
	}

	int ofileUtil(LG &M, string name){
		ofstream ofile;
		if (name == "admin")
			ofile.open("./systemFile/"+name  + ".dat", ios_base::trunc);
		else
			ofile.open("./systemFile/"+name  + ".dat", ios_base::app);
		if (!ofile){
			cout << "���ļ�ʧ��" << endl;
			return -1;
		}
		ofile.write((char *)&M, sizeof(M));
		ofile.close();
		return 0;
	}
	int ifileUtil(LG &M, string name){
		ifstream ifile("./systemFile/"+name  + ".dat", ios_base::in);
		if (!ifile){
			return -1;
		}
		ifile.read((char *)&M, sizeof(M));
		ifile.close();
		return 0;
	}
//-------------------------------------------------����Util------------------------------------------
	void updateUtil(AM &M){
		char num[10];//���
		char name[20];//����
		char sex[10];//�Ա�
		int age;//����
		char msg[200];//��Ϣ����
		cout << "\n--------------------------------------------------------\n"
			"1.��� 2.���� 3.�Ա� 4.���� 5.��Ϣ����" << endl;
		cout << "��������Ҫ�޸ĵ�ѡ�";
		int i = 0;
		cin >> i;
		switch (i){
		case 1:
			cout << "�����붯��ı�ţ�";
			cin >> num;
			while (AddAnimalUtil(M.pro, num) == -1){
				cout << "�ö������б���Ѵ��ڣ�����������!" << endl;
				cout << "�����붯��ı�ţ�";
				cin >> num;
			}
			strcpy_s(M.num, num);
			break;
		case 2:
			cout << "�����붯������֣�";
			cin >> name;
			strcpy_s(M.name, name);
			break;
		case 3:
			cout << "�����붯����Ա�";
			cin >> sex;
			strcpy_s(M.sex, sex);
			break;
		case 4:
			cout << "�����붯������䣺";
			cin >> age;
			M.age = age;
			break;
		case 5:
			cout << "�����붯�����Ϣ���ܣ�";
			cin >> msg;
			strcpy_s(M.msg, msg);
			break;
		default:
			system("cls");
			cout << "����������������룡";
			updateUtil(M);
		}
		//ofileUtil(M,M.pro,M.count);
		//cout << M.pro << "\t" << M.count<< endl;
		ofileUtil(M, M.pro, M.count);
		system("cls");
		cout << "�޸ĳɹ���" << endl;
	}
//--------------------------------------------��¼��ע����֤Util---------------------------------
	int logUtil(char *username, char *password){
		LG log;
		int i = 0;
		AS sum;
		ifileUtil(sum, "sum");
		//cout << sum.user << "---------" << endl;
		for (i = 0; i < sum.user; i++){
			ifileUtil(log,i,"user");
			if (strcmp(log.username, username) == 0 && strcmp(log.password, password) == 0)
				return 1;
		}
		return 0;
	}
	//�ο��˺Ų����ظ�  ��  ��ʽ��ȷ
	int AddUserUtil(char * username,char * password){

		LG M;
		AS sum;
		ifileUtil(sum, "sum");
		//cout << strlen(username) << "--------------" << endl;
		if (strlen(username) != 6)
			return -2;
		for (int i = 0; i < 6; i++){
			if (!(username[i] >= '0' || username[i] <= '9' || username[i] >= 'a' || username[i] <= 'z' || username[i] >= 'A' || username[i] <= 'Z'))
				return -2;
			if (!(password[i] >= '0' || password[i] <= '9' || password[i] >= 'a' || password[i] <= 'z' || password[i] >= 'A' || password[i] <= 'Z'))
				return -2;
		}
		for (int i = 0; i < sum.user; i++){
			ifileUtil(M, i, "user");
			if (!strcmp(M.username, username))
				return -1;
		}
		return 0;
	}
	//ͬһ�ද���Ų���һ��
	int AddAnimalUtil(string name, char * num){
		AS sum;
		AM M;
		int sumA= 0;
		ifileUtil(sum, "sum");
		if (name == "dog"){
			sumA= sum.dog;
		}
		else if (name == "tiger"){
			sumA = sum.tiger;
		}
		else if (name == "panda"){
			sumA = sum.panda;
		}
		else if (name == "lion"){
			sumA = sum.lion;
		}
		else if (name == "wolf"){
			sumA = sum.wolf;
		}
		for (int i = 0; i < sumA; i++){
			ifileUtil(M, i, name);
			if (!strcmp(M.num, num))
				return -1;
		}
		return 0;
	}
};