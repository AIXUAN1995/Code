using namespace std;
#include<string>
/*
	���еĶ�������
*/
//������Ϣ�����ԣ���ţ����֣��Ա����䣬��Ϣ����
//���ж���Ļ���
class Animal{
private:
	char property[10];//����
	char  num[20];//���
	char name[20];//����
	char sex[10];//�Ա�
	int age;//����
	char message[200];//��Ϣ����
public:
	Animal(){}//�չ��캯��
	//���εĹ��캯��
	Animal(char * pro, char * nu, char * na, char * se, int ag, char * mes){
		strcpy_s(property,pro);
		//property = pro;
		strcpy_s(num, nu);
		strcpy_s(name, na);
		strcpy_s(sex, se);
		age = ag;
		strcpy_s(message, mes);
	}
	void setProperty(char * pro){
		strcpy_s(property, pro);
	}
	char * getProperty(){
		return property;
	}
	void setNum(char * nu){
		strcpy_s(num , nu);
	}

	char * getNum(){
		return num;
	}
	void setName(char * na){
		strcpy_s(name, na);
	}
	char * getName(){
		return name;
	}
	void setSex(char * se){
		strcpy_s(sex,se);
	}
	char * getSex(){
		return sex;
	}
	void setAge(int age){
		age = age;
	}
	int getAge(){
		return age;
	}
	void setMessage(char * mes){
		strcpy_s(message , mes);
	}
	char * getMessage(){
		return message;
	}
};
//����
class Dog :public Animal{
public:
	Dog(){}
	Dog(char * pro, char * nu, char * na, char * se, int ag, char * mes):Animal(pro,nu,na,se,ag,mes){}
};
//�ϻ�
class Tiger :public Animal{
public:
	Tiger(){}
	Tiger(char * pro, char * nu, char * na, char * se, int ag, char * mes) :Animal(pro, nu, na, se, ag, mes){}
};
//��è
class Panda:public Animal{
public:
	Panda(){}
	Panda(char * pro, char * nu, char * na, char * se, int ag, char * mes) :Animal(pro, nu, na, se, ag, mes){}
};
//��
class Lion:public Animal{
public:
	Lion(){}
	Lion(char * pro, char * nu, char * na, char * se, int ag, char * mes) :Animal(pro, nu, na, se, ag, mes){}
};
//��
class Snake :public Animal{
public:
	Snake(){}
	Snake(char * pro, char * nu, char * na, char * se, int ag, char * mes) :Animal(pro, nu, na, se, ag, mes){}
};
//��
class Wolf :public Animal{
public:
	Wolf(){}
	Wolf(char * pro, char * nu, char * na, char * se, int ag, char * mes) :Animal(pro, nu, na, se, ag, mes){}
};