#include<iostream>
using namespace std;
#include"UIFunction.h"

int main()
{
	//cout << sizeof(AM) << endbl;

	UIFunction ui;
	/*
	LG log;
	strcpy_s(log.username,"admin");
	strcpy_s(log.password,"admin");
	util.ofileUtil(log, "admin");
	AS sum;
	cout << sum.dog << sum.tiger << endl;
	util.ofileUtil(sum, "sum");
	*/
	//for (int i = 0; i < 10; i++)
		//cout << str[i] << "\t";
	ui.wel();	
	//zsgc.selectUser();
	//zsgc.updateUser();
	//zsgc.selectUser();
	//ZSGCFunction zsgc;
	//zsgc.selectOneClass();
	//zsgc.selectOneClass();
	//zsgc.selectOne();
	//zsgc.updateAnimal();
	//zsgc.selectAll();
	system("pause");
	return 0;
}